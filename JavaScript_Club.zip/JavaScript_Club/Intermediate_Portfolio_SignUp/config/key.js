module.exports = {
    mongoURI: '',
    secretKey: 'secret'
};
