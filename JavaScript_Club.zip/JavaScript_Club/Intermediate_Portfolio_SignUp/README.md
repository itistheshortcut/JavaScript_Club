# Portfolio Application

### Required Tools: 
- NodeJS 
- Express
- Handlebar
- MongoDB 
- Mongoose 
___

# Installation
- create new folder
- run command: `git clone URL_Here`
- Open folder in VSCODE
- run command: `npm install`
___