//Assignment3

//creates the header h1 tag with class name header, text showing "Hello World" centered.


//creates the p tag with text showing "This is the first paragraph" class name is paragraph1.


//creates the p tag with text showing "This is the second paragraph" class name is paragraph2
//color is red and text is aligned on the right of the screen


//creates a new div element with id = div1 and has the text showing "Hello"
//when text "Hello is clicked", it changes to the text "I am from div1"

