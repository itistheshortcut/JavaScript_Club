function calcBMI(){
    //BMI Formula: BMI = kg/m^2   
    //1 meter = 100 centimeter: z = centimeter/100
}

function checkResult(result){
    //create a function that checks the BMI result  
    //Underweight = < 18.5
    //Normal weight = 18.5–24.9
    //Overweight = 25–29.9
    //Obesity = BMI of 30 or greater
}