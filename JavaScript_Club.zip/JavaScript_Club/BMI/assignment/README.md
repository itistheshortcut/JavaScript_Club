# BMI Program

***This lesson is about creating a body mass index calculating program***
___

# Requirements

- Basic knowledge of DOM manipulation
- Basic of variables
- Basic of functions and methods

___
# Installation


- `git clone URL_LINK_HERE`
- VSCODE Editor: [VSCODE]()
- github account: [Github SignUP Page]()

___

Documentation

- [HTML](https://www.w3schools.com/)

- [DOM Manipulation](https://wwww.w3schools.com/)

- [BootStrap]()

___