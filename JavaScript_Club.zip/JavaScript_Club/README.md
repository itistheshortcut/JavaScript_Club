#  The Shortcut JavaScript/EcmaScript Club
### The club provides free lessons and projects with JavaScript programming language to beginners and intermediate programmers.

___
## Lessons
- Intro to HTML, CSS
- Tools: `Git, NodeJS, Visual Studio Code`
- Basic JavaScript Lessons & Concepts: ***Data Types, Variables, Functions, If Statement, For Loop etc.***

- Intermediate Lessons & Concepts: ***OOP, Class, Instances, Array***
___
## Projects
- Beginner with Static: ***Portfolio Website***
- Intermediat with Full stack: ****Portfolio Application****
___
